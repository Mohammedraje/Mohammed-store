<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'mohammed' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'Y4WgAJ4~lV_$^YWgu)&j8k8ffut-G +)*9(z5&v5A) 0Z;Iqxjk7~{E5LJ6Ea_U{' );
define( 'SECURE_AUTH_KEY',  '96^H,>#]mu|u5 q0O0)b#SQCmP4uxE&qN{:AAj<*s_[zB&iUmyZQoQ%4MdzhNH!m' );
define( 'LOGGED_IN_KEY',    '6iIDM?+g*>i!xLJ<,u}p4O5].4H65Sm*p2Uvyi7Lz{4[34*,[GoY @FBgLY0_$5I' );
define( 'NONCE_KEY',        'ak^<y//!O;^.<zd@beJNCc{4/~q-xjyD%xhvUR6#YncjWl(2KlGm=W%&2uItiJfi' );
define( 'AUTH_SALT',        'Z/.dLST`$aCxLg4iI7S.T1.U+R@OL[LCm;FkVae52O{^Yj<M,TfRJJl%9DIjcGbj' );
define( 'SECURE_AUTH_SALT', ')B7<19?#s)}2,Veq;[v_8xX~NSDLlZ;nmPJwXcoL?`!:6mjV((xHTo)a0VQFh_bq' );
define( 'LOGGED_IN_SALT',   'v~{t>x*w0Y!E>-[YiI6fOd.j-neCM[u`N?&!z7huEI}&%FFyXP>,Z3)ibuld;@O)' );
define( 'NONCE_SALT',       '4iq1RO[R@g[lYS0^)l|]8B}d:t!WaYt?N1@!E${hS&9G8fLf%}k7n_!#b*H|Gsqf' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
